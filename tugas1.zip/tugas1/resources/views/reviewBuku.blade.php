@extends('mainLayout.main')

@section('container')
<div class="clearfix">
    <div class="container">
        <div class="row align-items-start">

          <div class="col">
            <h5>{{ $review_buku->Nama_Buku}}</h5>
            <p>{{ $review_buku->Harga}}</p>
            <p>{{ $review_buku->Sinopsis }}</p>
          </div>

          <div class="col">
            <img src="{{ asset('storage/'. $review_buku->Photo) }}" class="card-img-top">
        </div>
    </div>
@endsection