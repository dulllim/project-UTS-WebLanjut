@extends('mainLayout.main')

@section('container')
    <div class="row">
    @foreach ($allBuku as $no => $buku)
        <div class="col-4 mb-3">
            <div class="card" style="width: 18rem;">
            <img src="{{ asset('storage/'. $buku->Photo) }}" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">{{ $buku->Nama_Buku }}</h5>
                <p class="card-text">{{ $buku->Harga }}</p>
                <p class="card-text">{{ $buku->Stok }}</p>
                <p class="card-text">{{ $buku->Review }}</p>
                <a href="{{ route('reviewBK', $buku->id )}}" class="btn btn-secondary">Review</a>
            </div>
        </div>
    </div>
@endforeach
@endsection