<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Buku;
class BukuController extends Controller
{
    public function home(){
        $buku['allBuku'] = Buku::all();
        return view('home', ["title" => "home"], $buku);
    }

    public function review($id){
        $review_buku= Buku::find($id);
        return view('reviewBuku', ["title" => "buku"],compact('review_buku'), $review_buku);
    }
}
