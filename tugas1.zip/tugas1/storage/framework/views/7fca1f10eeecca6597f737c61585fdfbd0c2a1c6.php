

<?php $__env->startSection('container'); ?>
    <div class="row">
    <?php $__currentLoopData = $allBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 mb-3">
            <div class="card" style="width: 18rem;">
            <img src="<?php echo e(asset('storage/'. $buku->Photo)); ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($buku->Nama_Buku); ?></h5>
                <p class="card-text"><?php echo e($buku->Harga); ?></p>
                <p class="card-text"><?php echo e($buku->Stok); ?></p>
                <p class="card-text"><?php echo e($buku->Review); ?></p>
                <a href="<?php echo e(route('reviewBK', $buku->id )); ?>" class="btn btn-secondary">Review</a>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mainLayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Perkuliahan\semester3\Pemrograman Web Lanjut\tugas1\resources\views/home.blade.php ENDPATH**/ ?>