

<?php $__env->startSection('container'); ?>
<div class="clearfix">
    <div class="container">
        <div class="row align-items-start">

          <div class="col">
            <h5><?php echo e($review_buku->Nama_Buku); ?></h5>
            <p><?php echo e($review_buku->Harga); ?></p>
            <p><?php echo e($review_buku->Sinopsis); ?></p>
          </div>

          <div class="col">
            <img src="<?php echo e(asset('storage/'. $review_buku->Photo)); ?>" class="card-img-top">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mainLayout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Perkuliahan\semester3\Pemrograman Web Lanjut\tugas1\resources\views/reviewBuku.blade.php ENDPATH**/ ?>