<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Buku;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Buku::create([
            'Nama_Buku'=> 'Heartbreak Motel',
            'Harga'=> 'Rp. 80.000,00',
            'Stok'=> '50',
            'Review'=> 'Hidup ini tidak pernah berhenti menyembunyikan arti menyimpan misteri. Hidup tak selalu memberikan jawaban atas setiap pertanyaan yang muncul, dan waktu terus bergulir.',
            'Photo'=> 'motel.jpg',
            'Sinopsis'=> 'Hidup ini tidak pernah berhenti menyembunyikan arti menyimpan misteri. Hidup tak selalu memberikan jawaban atas setiap pertanyaan yang muncul, dan waktu terus bergulir. Satu jam, satu hari, satu minggu, satu bulan, satu momen.
            Pertanyaan dan permasalahan baru terus muncul, tanpa memedulikan masalah lama yang sudah ada sebelumnya, yang belum sempat terurai. Ava Alessandra menemukan panggilan hati sebagai seorang aktris sejak ia masih berusia enam belas tahun.
            Sebagai seorang aktris, Ava kerap berpindah dari satu peran ke peran lainnya. Baik itu peran yang ia pilih, atau peran yang dipilihkan untuknya. Ava berusaha untuk membuat semua takdir yang tidak dipahaminya menjadi terasa masuk akal.
            Ava tidak peduli bahwa setiap dirinya selesai menjalankan peran, ia harus menyendiri, jungkir balik memulihkan diri sendiri di satu tempat yang disebut Heartbreak Motel. Pada ulang tahunnya yang ketiga puluh, bermula dari tempat itu, sejumlah pertanyaan baru menyerangnya tumpang tindih. Pertanyaan yang muncul, karena kehadiran tiga lelaki yang mengisyaratkan dan mengecoh masa lalu, masa kini, dan masa depannya.'
        ]);

        Buku::create([
            'Nama_Buku'=> 'Shine',
            'Harga'=> 'Rp. 90.000,00',
            'Stok'=> '100',
            'Review'=> 'Shine menceritakan kisah tentang seorang gadis berusia tujuh belas tahun bernama Rachel Kim. Cerita dimulai dari masa-masa enam tahun perjalanan trainee-nya dalam suatu agensi besar Korea Selatan. ',
            'Photo'=> 'shine.jpeg',
            'Sinopsis'=>'Rachel di dalam buku ini diceritakan harus berkorban pindah ke Korea Selatan dari yang sebelumnya berada di Amerika Serikat. Hal ini membuat keluarganya juga harus ikut pindah ke Negeri Gingseng tersebut. Pengorbanan itu tidak hanya datang dari Rachel yang berjuang menjadi trainee, tetapi keluarganya juga jadi merintis ulang bisnisnya di Korea Selatan yang sebelumnya sudah dibangun besar di Amerika Serikat.
            Menjadi trainee dan sukses debut bukan menjadi satu-satunya tekanan yang Rachel miliki saat itu, namun juga datang dari harapan besar keluarga. Belum lagi lingkungan kerja yang keras, apalagi dikelilingi oleh trainee lain yang mencemooh dan membencinya, membuat Rachel harus mati-matian bertahan di sana.
            Statusnya sebagai orang blasteran Korea-Amerika, seringkali membuatnya mendapat diskriminasi dan bullying dari para trainee. Akan tetapi, drama yang dialaminya bukan hanya datang dari persoalan trainee saja, dalam buku ini kamu akan menyaksikan kisah cinta Rachel juga.
            Rachel memiliki kisah-kasih dengan salah satu anggota boy group satu agensinya bernama Jason Lee. Sayangnya hal ini juga menambah tekanan Rachel sebab hari-harinya terus digentayangi kekhawatiran. Apabila hubungannya diketahui agensi, maka mereka bisa mengancam Rachel untuk tidak didebutkan.'
        ]);

        Buku::create([
            'Nama_Buku'=> 'Laut Bercerita',
            'Harga'=> 'Rp. 60.000,00',
            'Stok'=> '40',
            'Review'=> 'Laut Bercerita adalah novel karya penulis asal Indonesia bernama Leila Salikha Chudori. Ia juga merupakan seorang wartawan di majalah Tempo.',
            'Photo'=> 'laut.jpg',
            'Sinopsis'=>'Laut adalah seorang mahasiswa program studi Sastra Inggris di Universita Gadjah Mada, Yogyakarta. Ia sangat menggeluti dunia sastra dan tentunya tidak sedikit buku sastra klasik yang dimilikinya, baik itu buku sastra bahasa Indonesia maupun bahasa Inggris.
            Laut gemar membaca berbagai buku karangan Pramoedya Ananta Toer yang ketika itu peredarannya dilarang di Indonesia. Hal itu yang menekatkan dirinya secara diam-diam untuk memfotokopi buku-buku tersebut di salah satu tempat yang disebut sebagai fotokopi terlarang. Mulai dari sana, dirinya bertemu dengan Kinan, salah satu mahasiswa FISIP yang memperkenalkan Laut akan organisasi Winatra dan Wirasena.
            Setelah ikut bergabung dengan organisasi Winatra, Laut jadi semakin menggiatkan aktivitas diskusi buku bersama rekan-rekan seorganisasi nya. Bukan hanya buku, melainkan beberapa konsep yang hendak mereka lakukan untuk menentang doktrin pemerintah di negara ini yang telah dipimpin oleh satu presiden selama lebih dari 30 tahun.
            Kegiatan Laut tidak hanya berdiskusi di organisasinya, ia juga gemar menulis. Laut kerap menuangkan gagasannya ke dalam bentuk tulisan, kemudian tulisan itu ia kirim agar dapat dimuat oleh media cetak harian. Laut juga beberapa kali bekerja sebagai translator, misal, penerjemah dari novel bahasa Inggris ke bahasa Indonesia.
            Dalam novel ini, diceritakan bahwa Laut beserta rekan-rekannya melaksanakan beberapa aksi atau gerakan untuk membela rakyat yang telah diambil haknya oleh pemerintah, salah satunya “Aksi Tanam Jagung Blangguan”.
            Akan tetapi, jauh sebelum mereka melakukan aksi tersebut, Laut bersama teman-temannya berdiskusi terlebih dahulu yang dikenal sebagai diskusi kwangju. Dari situlah, awal mula Laut dan rekan-rekannya mengetahui dan mengenal arti dari sebuah pengkhianatan.
            Diskusi kwangju yang semestinya berlangsung baik dan lancar justru terhambat karena adanya intel yang secara tiba-tiba mendatangi markas mereka. Namun, tidak ada yang tahu pelaku yang membocorkan diskusi mereka. Beberapa anggota dari organisasi Winatra sedikit menaruh curiga pada Naratama sebab dirinya tidak pernah tampak saat penangkapan dilakukan, tetapi itu hanyalah dugaan mereka. Belum diketahui kebenaran yang sesungguhnya seperti apa.
            Sesudah melancarkan aksi tanam jagung di Blangguan, Laut beserta rekan-rekannya kembali ke terminal. Mereka berpisah-pisah, ada yang ke Pacet, kemudian ada yang ke Yogyakarta. Saat berada di ruang tunggu bis, terdapat sekelompok orang mencurigakan yang mengintai mereka. Hingga akhirnya, Laut, Bram, dan Alex, sementara yang lainnya entah melarikan diri ke mana.
            Laut, Bram, dan Alex dibawa ke suatu tempat, semacam markas tentara. Di markas, sekelompok orang itu menginterogasi Laut, Bram, dan Alex. Tidak hanya diinterogasi, mereka pun diperlakukan secara tidak manusiawi, seperti disiksa, diinjak, dipukul, dan disetrum. Pertanyaan sekelompok orang tersebut tidak lain adalah siapa dalang atas aktivitas yang mereka lakukan.
            Setelah kurang lebih dua hari satu malam, penganiayaan dan penyekapan itu pun berakhir. Laut, Bram, dan Alex dikembalikan ke terminal Bungurasih. Di terminal Bungurasih, Laut, Bram, dan Alex dijemput oleh kedua kakak dari Anjani. Mereka bertiga dibawa dan ditempatkan ke sebuah tempat yang aman di Pacet. Di sana ada Daniel, Kinan, Anjani, beserta teman-teman yang lain menunggu mereka.
            Singkatnya, Laut diringkus lagi oleh sekelompok orang yang tidak dikenal, tepatnya tanggal 13 Maret 1998. Semenjak mereka menjadi buronan di tahun 1996 sebab organisasi Winatra dan Wirasena dikatakan berbahaya bagi pemerintah kemudian Sunu, Mas Gala, dan Narendra secara tiba-tiba hilang. Kemudian, lambat laun beberapa rekan-rekan yang lain pun hilang entah ke mana. Lalu, sekarang Laut disusul oleh Alex dan Daniel yang menghilang.
            Saat penculikan dan penyekapan itu, mereka memperoleh siksaan yang sangat tidak manusiawi, bisa dikatakan sangat sadis dan biadab. Mereka semua dipukuli, disiram dengan air es, disetrum, digantung dengan kaki yang berada di atas dan kepala berada di bawah, ditelentangkan di atas batangan es yang sangat dingin, serta penyiksaan lainnya.
            Di bagian pertama, tidak hanya membicarakan terkait aktivitas Laut dan teman-temannya dalam pergerakan yang hendak mereka jalani, melain ada pula sisipan kisah antara Laut dan anggota keluarganya. Saat Laut dan teman-temannya menghilang, semua kehidupan mereka dan orang-orang terdekat mereka pun senantiasa berubah.
            Sejak Laut kuliah di Yogyakarta, ia dengan bapak, ibu, dan Asmara (adiknya Laut) semakin jarang berkumpul bersama. Oleh sebab itu, bapaknya memutuskan bahwa hari Minggu adalah hari bersama untuk keluarga mereka, tidak boleh ada yang mengganggu. Saat makan malam adalah hal yang paling menarik bisa dikatakan menjadi sebuah ritual bagi mereka. Di sana adanya kebersamaan dan kebahagiaan yang terpancar dari wajah-wajah mereka.'
        ]);

        Buku::create([
            'Nama_Buku'=> 'Komet',
            'Harga'=> 'Rp. 100.000,00',
            'Stok'=> '50',
            'Review'=> 'Di novel ini masih menceritakan petualangan Raib, Seli, dan Ali. Sebuah persahabatan yang tulus, penuh pengorbanan, mengharukan, berani, dan bernas akan kebaikan sebab memang hal-hal demikianlah yang menjadi sumber kekuatan terbesar dalam dunia paralel.',
            'Photo'=> 'komet.jpg',
            'Sinopsis'=>'Ali sibuk mencari info terkait klan Komet lewat berbagai buku yang ditinggalkan oleh Zaad di Ruangan Padang Sampah Klan Bintang sebab dirinya telah mengetahui bahwa si Tanpa Mahkota sedang mencari klan Komet guna melengkapkan kekuatannya. Ternyata, gerbang menuju klan Komet berada di klan Matahari. Ali pun bergegas memberi tahu Miss Selena dan Av terkait si Tanpa Mahkota dan keberadaan portal menuju klan Komet.
            Sebelum si Tanpa Mahkota, mereka harus menemukan klan Komet terlebih dahulu. Akan tetapi, portal atau gerbang menuju klan Komet hanya bisa dibuka oleh bunga matahari pertama mekar pada Festival Bunga Matahari yang diadakan di klan Matahari setiap tahunnya.
            Si Tanpa Mahkota telah berhasil membukanya dan masuk ke gerbang menuju klan Komet, kemudian disusul oleh Ali, Seli, dan Raib ketika mereka bertiga sedang bertempur melawan si Tanpa Mahkota di stadion kota Ilios. Akhirnya, mereka berempat sudah menuju klan Komet dan mencari pulau kecil di sentral lautan biru dengan tumbuhan-tumbuhan aneh.
            Di klan Komet lah, petualangan tiga sekawan, yakni Raib, Ali, dan Seli dimulai.
            Ali yang dengan sengaja masuk ke dalam portal untuk mengikuti si Tanpa Mahkota mengakibatkan mereka bertiga tersesat di dunia antah-berantah. Gerbang atau portal tersebut mengarah pada pulau dengan berbagai tumbuhan aneh.
            Namun, ternyata tempat itu adalah klan Komet yang terdiri dari kumpulan pulau-pulau, di antaranya Pulau Hari Senin, Pulau Hari Selasa, Pulau Hari Rabu, Pulau Hari Kamis, Pulau Hari Jumat, Pulau Hari Sabtu, dan Pulau Hari Minggu. Untuk melintasi kumpulan berbagai pulau tersebut, tentu tidaklah mudah sebab akan ada banyak rintangan yang perlu dilalui.
            Terdapat pulau kecil dengan tumbuhan aneh bernama Pulau Hari Minggu, pintu untuk membuka gerbang dunia lain yang disebut sebagai Komet Minor. Belum pernah ada yang mendapati pulau ini sebab tidak lolos dengan berbagai ujian di pulau-pulau sebelumnya.
            Di Pulau Hari Senin, mereka melintasi tes kejujuran dengan menolak untuk mencuri makanan di perahu, mereka mencoba sabar meredam rasa lapar serta udara yang dingin. Akhirnya mereka bersua dengan paman Kay dan diajak ke kediamannya yang berada di desa bawah tanah dengan disambut oleh bibi Nay.
            Setelah itu, mereka mendatangi Pulau Hari Selasa, bertemu dan menolong seseorang bernama Max. Ia kapalnya telah dirompak sehingga ia pun kehilangan semua hartanya, kemudian Max ikut pada Ali, Raib, dan Seli berjelajah. Max yang mengendarai kapal mereka.
            Saat di Pulau Hari Selasa, mereka menghadapi tes atau ujian kepedulian dengan membantu Cindanita mencari dan menemukan bonekanya. Mereka pun sabar dalam mencari boneka tersebut dan bertempur melawan binatang laut besar, bisa dikatakan raksasa.
            Lalu, di Pulau Hari Rabu, mereka menghadapi ujian atau tes kesabaran sebab mereka harus sabar mendengarkan ocehan petani Kay selama sepanjang hari, bahkan Seli yang mendengarkan ocehan petani Kay sampai petani Kay pun tertidur akibat kelelahan berbicara. Tak hanya itu, mereka pun menghadapi tes kecerdasan ketika bertarung melawan komplotan burung hitam.
            Di Pulau Hari Kamis, mereka harus melalui tes ketulusan dengan memberikan pengobatan kepada para perompak yang sedang merasakan kesakitan, kemudian mengobati dorokdok-dok, yakni pemimpin dari perompak. Ia sedang mengalami sakit keras akibat memakai alat berkekuatan.
            Saat menuju ke Pulau Hari Sabtu, mereka menghadapi tes ketangguhan dengan terus-menerus mengayuh belahan papan bambu dan melewati rintangan, yakni gurita raksasa yang memusnahkan kapal mereka.
            Sesampainya di Pulau Hari Sabtu, mereka harus menghadapi dan melewati tes terakhir, yaitu ujian melepaskan. Mereka mengurungkan peluang pergi ke klan Komet Minor sebab pemegang kunci lautan adalah paman Kay dan istrinya, yakni bibi Nay sedang menguji Raib dan kawan-kawannya. Mereka diperintahkan untuk membunuh paman Kay dan bibi Nay agar dapat melewati cermin.
            Akan tetapi, Ali, Raib, dan Seli menolak untuk melakukan hal tersebut. Bibi Nay memiliki kekuatan untuk menerawang dan membaca pikiran orang, ia pun melihat kebaikan dan ketulusan hati dari Raib, Seli, dan Ali. Mereka pun lolos di ujian terakhir dan berhasil ke Pulau Hari Minggu. Pulau itu berada di tengah lautan yang mana terdapat tumbuhan aneh. Akhirnya, mereka bertiga dan Max melewati cermin tersebut dengan mudah.
            Saat mereka bersiap melompat ke pulau dengan sebuah biji raksasa yang mengapung, di sinilah sebuah pengkhianatan terungkap.'
        ]);

        Buku::create([
            'Nama_Buku'=> 'kita pergi hari ini',
            'Harga'=> 'Rp. 50.000,00',
            'Stok'=> '60',
            'Review'=> 'Awal mula melihat sampul buku ini, dengan gambar lima anak kecil yang sedang menatap ke daerah perbukitan yang cantik, kita pasti berpikir bahwa buku ini adalah buku yang manis dan menyenangkan.',
            'Photo'=> 'kita.jpg',
            'Sinopsis'=>'Dikisahkan ada sebuah kota yang disebut sebagai Kota Suara, yang mana di kota ini, jumlah populasi anak kecil jauh lebih banyak dibandingkan dengan jumlah populasi orang dewasa.
            Dari banyaknya jumlah populasi anak-anak, ditambah dengan sifat alami anak kecil, terdapat banyak keributan di kota tersebut. Keributan yang disebabkan anak-anak yang tertawa, teriak, menangis, dan menjerit.
            Oleh karena keributan ini, masyarakat Kota Suara mulai melupakan nama asli dari kota tersebut. Dan dari situ lah asal usul kota tersebut disebut sebagai Kota Suara.
            Kisah ini berawal dari salah satu keluarga kecil di Kota Suara, yang beranggotakan lima orang. Seorang ayah, ibu, dan tiga orang anaknya. Keluarga ini disebut sebagai Keluarga Mo, di mana ada Bapak Mo, Ibu Mo, dan tiga anak yang bernama Ma, Mi, dan Mo.
            Kondisi ekonomi di Kota Suara menuntut penduduknya untuk mencari uang lebih. Sebab seluruh harta Kota Suara telah diraup habis oleh para penjahat. Seluruh uang yang ada di dasar laut diambil oleh para perompak, seluruh uang yang ada di bawah tanah diambil oleh para perampok, dan seluruh uang yang ada di ranting pohon diambil oleh pengusaha kayu yang jahat.
            Orang-orang dewasa yang menempati Kota Suara setiap harinya harus bekerja keras demi menghasilkan uang, untuk dapat menghidupi dirinya sendiri beserta keluarganya. Tidak terkecuali Bapak Mo dan Ibu Mo.
            Aktivitas keseharian Bapak Mo dan Ibu Mo adalah bekerja, dan sebagian besar waktu mereka habis karena sibuk bekerja. Maka itu, Bapak Mo dan Ibu Mo tidak memiliki banyak waktu yang dapat dihabiskan untuk mengurus dan bermain bersama anak-anaknya.
            Memakai jasa seorang pengasuh anak bukan lah suatu pilihan bagi Keluarga Mo, karena Bapak dan Ibu Mo tidak mempunyai uang lebih untuk membayar jasa tersebut.
            Namun, terdapat satu pilihan yang memungkinkan para keluarga yang kondisinya seperti Keluarga Mo, yang tidak memiliki penghasilan yang banyak, tetapi juga tidak memiliki waktu untuk menjaga anak-anaknya, yakni dengan memakai jasa pengasuh berbentuk kucing luar biasa yang tidak perlu dibayar atau gratis.
            Kucing luar biasa berasal dari sebuah kota di luar Kota Suara yang bernama Kota Terapung Kucing Luar Biasa. Sesuai dengan namanya, seluruh populasi kota ini adalah kucing.
            Kucing luar biasa bukan lah sebuah sebutan tanpa makna, melainkan sebutan yang menggambarkan keadaan para kucing penduduk Kota Terapung Kucing Luar Biasa. Kucing-kucing penduduk kota tersebut tidak seperti hewan kucing biasa, tetapi para kucing tersebut menyerupai seorang manusia.
            Berjalan dengan dua kaki, memiliki dua tangan, bisa berbicara, bisa melakukan aktivitas manusia dalam kehidupan sehari-hari, dan memiliki akal seperti manusia. Begitu juga dengan pengasung yang disewa jasanya oleh Bapak dan Ibu Mo.
            Pengasuh kucing luar biasa ini meminta Keluarga Mo untuk memanggilnya Nona Gigi.
            Kehadiran Nona Gigi ke dalam Keluarga Mo membawa kedamaian hati bagi Bapak dan Ibu Mo. Sebab, dengan hadirnya Nona gigi, kehidupan anak-anak Bapak dan Ibu Mo, yakni Ma, Mi, dan Mo menjadi terurus, dan mereka dapat terus bekerja keras dengan merasa tenang.
            Kehadiran Nona Gigi kemudian memungkinkan Ma, Mi, dan Mo untuk bersosialisasi ke luar rumah. Ma, Mi, dan Mo kemudian berkenalan dan dekat dengan dua anak kembar yang tinggal di samping rumahnya. Kedua anak tersebut bernama Fifi dan Fufu.
            Ma, Mi, dan Mu, serta Fifi dan Fufu berteman baik dan saling berbagi cerita. Ternyata, mereka memiliki satu cerita yang sama, yakni orang tua mereka berlima memiliki janji untuk membawa mereka semua pergi jalan-jalan.
            Berdasarkan sifat alami seorang anak kecil, ketika mereka diberikan sebuah janji, maka mereka akan menagihnya sewaktu-waktu. Ma, Mi, dan Mo, serta Fifi dan Fufu kemudian menagih janji para orang tuanya.
            Pada akhirnya, orang tua mereka menepati janji tersebut dengan memutuskan satu hari di mana mereka dapat pergi jalan-jalan. Namun, oleh sebab kondisi hidup mereka yang pas-pasan, orang tua mereka tidak dapat menemani anak-anaknya jalan-jalan, karena tidak dapat meninggalkan pekerjaan.
            Akhirnya para orang tua pun meminta Nona Gigi sebagai pendamping alan-jalan Ma, Mi, Mo, Fifi, dan Fufu. Para anak-anak memutuskan untuk pergi ke Kota Terapung Kucing Luar Biasa. Dari sini lah kisah perjalanan yang tidak terduga dimulai.
            Untuk dapat sampai ke Kota Terapung Kucing Luar Biasa, mereka harus naik kendaraan yang disebut kereta air. Kereta air ini memiliki bentuk yang unik, bentuk badan kereta air menyerupai sebuah daun, jadi tiap-tiap penumpangnya akan duduk di sebuah daun. Sedangkan, lantai pijakan dari kereta air akan berubah menjadi air ketika para penumpang duduk.
            Perjalanan menuju Kota Terapung Kucing Luar Biasa mengharuskan mereka untuk singgah di sebuah tempat yang bernama Sirkus Sendu. Tidak seperti sirkus pada umumnya, yang mana setelah menonton sirkus para penontonnya akan merasa senang, Sirkus Sendu adalah kebalikannya.
            Reaksi para penonton setelah menonton Sirkus Sendu adalah merasakan kesedihan, bahkan hingga menangis. Bukan tanpa tujuan Sirkus Sendu ini diadakan, karena tangisan para penumpang yang menonton Sirkus Sendu merupakan bahan bakar kererta air, yang memungkinkan mereka untuk pergi ke Kota Terapung Kucing Luar Biasa.
            Akhirnya, mereka pun dapat sampai ke Kota Terapung Kucing Luar Biasa. Pemandangan pertama yang disuguhkan sesampainya di sana adalah pemandangan yang mengagumkan bagi seorang manusia.
            Bagaimana tidak, para kucing di sana sungguh hidup seperti para manusia. Memiliki rumah, memiliki pekerjaan, ada yang bekerja di darat, bekerja di laut, dan melakukan aktivitas manusia lainnya.
            Ma, Mi, Mo, Fifi, dan Fufu, bersama dengan Nona Gigi pun melanjutkan perjalanan menyusuri Kota Terapung Kucing Luar Biasa. Nona Gigi membawa mereka berpetualang menyusuri Kota Terapung Kucing Luar Biasa yang indah dan megah.
            Namun, petualangan mereka tidak berjalan seperti ekspektasi. Tak lama setelah petualangan dimulai, keanehan mulai terjadi, muncul masalah demi masalah dan juga ancaman, kebenaran mulai terkuak.
            Petualangan kelima anak kecil tersebut dipenuhi oleh kejadian mengerikan yang bertubi-tubi. Bahkan, kejadian mengerikan yang terburuk dapat mengorbankan keselamatan nyawa Ma, Mi, Mu, Fifi, dan Fufu.'
        ]);

        Buku::create([
            'Nama_Buku'=> 'Komet Minor',
            'Harga'=> 'Rp. 70.000,00',
            'Stok'=> '20',
            'Review'=>' Komet Minor merupakan lanjutan dari novel sebelumnya, yakni Komet, tetapi dalam novel ini petualangan Raib, Ali, dan Seli ditemani oleh Batozar.',
            'Photo'=> 'minar.jpg',
            'Sinopsis'=>'Saat detik-detik terakhir di pesisir pulau gerbang klan Komet Minor, secara diam-diam Ali mencoba untuk memanggil Batozar melalui cermin yang kerap dibawanya. Kemudian, Batozar hadir dan melindungi Raib serta kawan-kawannya. Di saat yang bersamaan, seekor paus raksasa muncul dan memakan pulau di mana tempat mereka berada.
            Raib dan yang lain beserta pulaunya pun ada di dalam perut paus raksasa itu. Batozar yang saat itu sempat membekukan si Tanpa Mahkota untuk sementara waktu, melarikan diri bersama Raib dan teman-teman. Hingga tibalah mereka di sebuah klan, yakni klan Komet Minor.
            Di sana pun, mereka terus-menerus melancarkan pelarian, terus menghindari si Tanpa Mahkota dan mencari-cari keberadaan kota-kota di klan Komet Minor. Akan tetapi, pelarian yang mereka lakukan tidak luput dari permasalahan. Pernah, pada saat itu mereka sedang latihan bertarung di semacam padang rumput, kemudian berbagai cacing pasak yang berada di bawah tanah pun terganggu, akhirnya cacing-cacing tersebut naik ke permukaan.
            Batozar, Raib, Seli, dan Ali melawan semua cacing yang telah muncul ke permukaan tersebut. Sebelum mereka berhasil menang, Seli terkena gigitan cacing tersebut, hingga mengakibatkan racun berbahaya yang berasal dari gigitan cacing itupun tertanam di tubuh Seli. Berhubung efek racun cacing di badan Seli munculnya tidak terlalu sering, Batozar terus mencari-cari informasi.
            Mereka pun memutuskan untuk meneruskan perjalanan untuk mencari sebuah kota yang dapat berpindah-pindah. Mereka mendapati sebuah kota yang bertepatan sedang singgah di suatu kaki bukit atau lembah, bernama Kota Barchantum. Di kota tersebut, mereka berjumpa dengan dua penduduk dari klan lain, yakni ST4R dan SP4RK. Mereka pun saling bertukar informasi.
            Kemudian, Berdasarkan informasi yang didapat dari ST4R, Batozar segera mencari petunjuk atau panduan terkait senjata yang dicari-cari oleh si Tanpa Mahkota. Mereka mendapat petunjuk yang pada akhirnya membawa mereka pada Tuan Entre, yakni seorang laki-laki tua yang mana dirinya merupakan mantan salah satu dari anggota Para Pemburu. Awalnya, Tuan Entre enggan angkat bicara.
            Hingga akhirnya, ia pun mau untuk membantu dan menceritakan terkait aliansi “Para Pemburu” yang salah satu dari anggotanya menciptakan sebuah senjata pusaka, yakni berupa tombak. Tombak pusaka tersebut merupakan senjata yang paling kuat dalam dunia paralel dan tombak tersebut dibagi menjadi tiga pecahan serta dipencar ke berbagai tempat yang mana masing-masingnya dijaga oleh anggota dari Para Pemburu.
            Tuan Entre meminta Raib dan kawan-kawan untuk mendatangi Arci, yakni salah satu dari empunya tiga pecahan senjata pusaka–tombak–tersebut. Arci tinggal di sebuah tempat yang sangat amat terasing di tengah hutan yang penuh akan kadal purba raksasa. Hewan purba raksasa itu dapat melemparkan semacam api yang berbentuk seperti bola-bola. Kawasan itupun juga sekitarnya terdapat gunung-gunung aktif yang hanya tinggal menunggu meletus.
            Secara terpaksa, rombongan Raib mendaratkan kapsul terbangnya dekat dengan kelompok kadal untuk mencoba berkomunikasi dengan alam. Nahasnya, mereka terlihat dan dalam hitungan detik saja, ratusan kadal purba raksasa itu mengejar Raib beserta rombongannya.
            Dengan keadaan nyaris terbunuh, akhirnya mereka sampai di kawasan menara kelabu, tepatnya kediaman Arci. Ia merupakan sosok yang terbilang sangat sakti, bahkan sudah tiga kali Batozar dan lainnya berusaha menaiki dan memanjat menara, tetapi senantiasa digagalkan oleh Arci. Mereka pun mendapati suatu cara, hingga akhirnya berhasil menaiki menara tempat Arci tinggal.
            Sesampainya di sana, Arci menyerahkan potongan atau pecahan pertama dari senjata pusaka (tombak) tersebut. Arci meminta mereka untuk mendatangi kota Archantum sebab potongan tombak pusaka yang kedua berada di sana.
            Saat di tengah perjalanan menuju ke sana, mereka dihalangi oleh si Tanpa Mahkota. Mereka bertarung mati-matian melawan si Tanpa Mahkota, tetapi sayangnya ia berhasil mencuri potongan tombak pusaka yang dibawa oleh rombongan Raib.
            Mereka pun tetap meneruskan perjalanan ke kota Archantum dengan menumpang di sebuah desa yang akan beralih tempat ke dekat kota Archantum. Lalu, setelah sampai di kota besar tersebut, mereka lekas mengetahui pemegang potongan kedua tombak pusaka, yakni Nyonya Kulture.
            Sama seperti sebelumnya, tetapi setelah melewati berbagai tantangan, Nyonya Kulture memberikan potongan kedua dari tombak pusaka, sekaligus memberi tahu petunjuk selanjutnya. Mereka diharuskan pergi ke sebuah pertambangan kuno untuk menemui pemegang potongan tombak pusaka yang ketiga, orang tersebut bernama Finale.
            Lagi dan lagi, si Tanpa Mahkota mengadang Raib dan rombongan di tengah jalan. Mereka mencoba untuk melawan dan bertarung dengan si Tanpa Mahkota, tetapi potongan kedua dari tombak pusaka itu berhasil diambil olehnya. Sebelum memutuskan pergi, si Tanpa Mahkota sempat mengatakan bahwa Ali merupakan seorang keturunan murninya.
            Saat sebelum sempat dibunuh, Batozar dan lainnya melakukan teleportasi melalui gerbang cermin ke ruang studio akting milik Nyonya Kulture, di Archantum. Intuisi Batozar mengarahkan mereka pada kediaman Kulture yang sebagian hancur. Dengan menyusup, mereka berhasil masuk dan mendapati ruang rahasia yang diisi oleh Tuan Entre, Arci, dan Nyonya Kulture. Namun, terlepas dari rumor yang menyatakan Aeci dan Nyonya Kulture telah mati, mereka nyatanya masih hidup dan berada di situ.
            Raib beserta rombongannya dan tiga anggota dari Para Pemburu membuat suatu rencana untuk menaklukkan si Tanpa Mahkota. Dengan gerbang cermin, mereka beralih ke kediaman Finale yang di sana juga sudah ada si Tanpa Mahkota. Pertarungan pun memanas, bahkan kekuatan si Tanpa Mahkota tidak ada yang dapat menandingi lagi, terkecuali Finale sebab dirinya berkekuatan besar pula. Namun, sayangnya si Tanpa Mahkota kembali berhasil mengambil potongan ketiga dari tombak pusaka itu.'
        ]);
    }
}
